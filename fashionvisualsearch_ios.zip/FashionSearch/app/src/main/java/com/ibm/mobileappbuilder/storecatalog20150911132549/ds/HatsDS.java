
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;

import ibmmobileappbuilder.ds.Count;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.Distinct;
import ibmmobileappbuilder.ds.Pagination;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import ibmmobileappbuilder.util.FilterUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * "HatsDS" static data source (b140d550-cf29-4f16-8db3-d576e8ba411d)
 */
public class HatsDS implements Datasource<HatsDSSchemaItem>, Count,
            Pagination<HatsDSSchemaItem>, Distinct {

    private static final int PAGE_SIZE = 20;

    private SearchOptions searchOptions;

    public static HatsDS getInstance(SearchOptions searchOptions){
        return new HatsDS(searchOptions);
    }

    private HatsDS(SearchOptions searchOptions){
        this.searchOptions = searchOptions;
    }

    @Override
    public void getItems(Listener<List<HatsDSSchemaItem>> listener) {
        listener.onSuccess(HatsDSItems.ITEMS);
    }

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getItem(String id, Listener<HatsDSSchemaItem> listener) {
        final int pos = Integer.parseInt(id);
        if(HatsDSItems.ITEMS.size() <= pos){
        	listener.onSuccess(new HatsDSSchemaItem());
        }
        else {
	        HatsDSSchemaItem dc = HatsDSItems.ITEMS.get(pos);
	        if( dc != null)
	            listener.onSuccess(dc);
	        else
	            listener.onFailure(new IllegalArgumentException("HatsDSSchemaItem not found: " + pos));
	    }
    }

    @Override public int getCount(){
        return HatsDSItems.ITEMS.size();
    }

    @Override
    public void getItems(int pagenum, Listener<List<HatsDSSchemaItem>> listener) {
        int first = pagenum * PAGE_SIZE;
        int last = first + PAGE_SIZE;
        ArrayList<HatsDSSchemaItem> result = new ArrayList<HatsDSSchemaItem>();
        List<HatsDSSchemaItem> filteredList = applySearchOptions(HatsDSItems.ITEMS);
        if(first < filteredList.size())
            for (int i = first; (i < last) && (i < filteredList.size()); i++)
                result.add(filteredList.get(i));

        listener.onSuccess(result);
    }

    @Override
    public void onSearchTextChanged(String s){
        searchOptions.setSearchText(s);
    }

    @Override
    public void addFilter(Filter filter){
        searchOptions.addFilter(filter);
    }

    @Override
    public void clearFilters() {
        searchOptions.setFilters(null);
    }

    private List<HatsDSSchemaItem> applySearchOptions(List<HatsDSSchemaItem> result) {
        List<HatsDSSchemaItem> filteredList = result;

        //Searching options
        String searchText = searchOptions.getSearchText();

        if(searchOptions.getFixedFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFixedFilters());

        if(searchOptions.getFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFilters());

        if (searchText != null && !"".equals(searchText))
            filteredList = applySearch(filteredList, searchText);

        //Sorting options
        Comparator comparator = searchOptions.getSortComparator();
        if (comparator != null) {
            if (searchOptions.isSortAscending()) {
                Collections.sort(filteredList, comparator);
            } else {
                Collections.sort(filteredList, Collections.reverseOrder(comparator));
            }
        }

        return filteredList;
    }

    private List<HatsDSSchemaItem> applySearch(List<HatsDSSchemaItem> items, String searchText) {
        List<HatsDSSchemaItem> filteredList = new ArrayList<>();

        for (HatsDSSchemaItem item : items) {
                        
            if (FilterUtils.searchInString(item.id, searchText) ||
            FilterUtils.searchInString(item.text1, searchText) ||
            FilterUtils.searchInString(item.text2, searchText) ||
            FilterUtils.searchInString(item.text3, searchText))
            {
                filteredList.add(item);
            }
        }

        return filteredList;

    }

    private List<HatsDSSchemaItem> applyFilters(List<HatsDSSchemaItem> items, List<Filter> filters) {
        List<HatsDSSchemaItem> filteredList = new ArrayList<>();

        for (HatsDSSchemaItem item : items) {
            if (
                FilterUtils.applyFilters("id", item.id, filters) &&
                FilterUtils.applyFilters("text1", item.text1, filters) &&
                FilterUtils.applyFilters("text2", item.text2, filters) &&
                FilterUtils.applyFilters("picture", item.picture, filters) &&
                FilterUtils.applyFilters("text3", item.text3, filters)
                ){

                filteredList.add(item);
            }
        }

        return filteredList;
    }

    // Distinct interface

    @Override
    public void getUniqueValuesFor(String columnName, Listener<List<String>> listener) {
        List<HatsDSSchemaItem> filteredList = applySearchOptions(HatsDSItems.ITEMS);
        listener.onSuccess(mapItems(filteredList, columnName));
    }

    private List<String> mapItems(List<HatsDSSchemaItem> items, String columnName){
        // return only unique values
        ArrayList<String> res = new ArrayList();
        for (HatsDSSchemaItem item: items){
            String mapped = mapItem(item, columnName);
            if(mapped != null && !res.contains(mapped))
                res.add(mapped);
        }

        return res;
    }

    private String mapItem(HatsDSSchemaItem item, String columnName){
        // get fields
        switch (columnName){
                        
            case "id":
                return item.id;
            
            case "text1":
                return item.text1;
            
            case "text2":
                return item.text2;
            
            case "text3":
                return item.text3;
            default:
               return null;
        }
    }
}


