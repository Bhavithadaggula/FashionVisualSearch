

package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// HatsDSSchemaItem static data
public class HatsDSItems{

    public static List<HatsDSSchemaItem> ITEMS = new ArrayList<HatsDSSchemaItem>();
    static {
        // Add items.
        HatsDSSchemaItem item;
        item = new HatsDSSchemaItem();
        item.text3 = "90";
        item.text2 = "Men";
        item.text1 = "Hats";
        item.picture = R.drawable.jpg_ldqrunj3x1;
        item.id = "57ef82829d17e00300d4df96";
        addItem(item);
        item = new HatsDSSchemaItem();
        item.text3 = "56";
        item.text2 = "Men";
        item.text1 = "Hats";
        item.picture = R.drawable.jpg_so6wmjudnp;
        item.id = "57ef82b89d17e00300d4df98";
        addItem(item);
        item = new HatsDSSchemaItem();
        item.text3 = "34";
        item.text2 = "Men";
        item.text1 = "Hats";
        item.picture = R.drawable.jpg_m1tnqkd3xy;
        item.id = "57ef82c357acb003000665a9";
        addItem(item);
        item = new HatsDSSchemaItem();
        item.text3 = "44";
        item.text2 = "Men";
        item.text1 = "Hats";
        item.picture = R.drawable.jpg_ve2toxdhaa;
        item.id = "57ef82cf9d17e00300d4df9a";
        addItem(item);
        item = new HatsDSSchemaItem();
        item.text3 = "67";
        item.text2 = "Men";
        item.text1 = "Hats";
        item.picture = R.drawable.jpg_yb5zonj4xd;
        item.id = "57ef82db57acb003000665ab";
        addItem(item);
        item = new HatsDSSchemaItem();
        item.text3 = "76";
        item.picture = R.drawable.jpg_gbxocx0evw;
        item.text2 = "Men";
        item.text1 = "Hats";
        item.id = "57ef83b29d17e00300d4df9c";
        addItem(item);
        item = new HatsDSSchemaItem();
        item.picture = R.drawable.jpg_ri44hgcu10;
        item.text2 = "Men";
        item.text1 = "Hats";
        item.id = "57ef83db57acb003000665b0";
        addItem(item);
    }
    public static void addItem(HatsDSSchemaItem item) {
        ITEMS.add(item);
    }
}


