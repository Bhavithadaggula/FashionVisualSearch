

package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// WatchesDSSchemaItem static data
public class WatchesDSItems{

    public static List<WatchesDSSchemaItem> ITEMS = new ArrayList<WatchesDSSchemaItem>();
    static {
        // Add items.
        WatchesDSSchemaItem item;
        item = new WatchesDSSchemaItem();
        item.text3 = "109";
        item.picture = R.drawable.jpg_jgujol0216;
        item.text2 = "Women";
        item.text1 = "Watch";
        item.id = "57ef818057acb003000665a0";
        addItem(item);
        item = new WatchesDSSchemaItem();
        item.text3 = "456";
        item.text1 = "Watch";
        item.text2 = "Women";
        item.picture = R.drawable.jpg_3h9jfhrkfs;
        item.id = "57ef81e19d17e00300d4df8e";
        addItem(item);
        item = new WatchesDSSchemaItem();
        item.text3 = "678";
        item.text1 = "Watch";
        item.text2 = "Women";
        item.picture = R.drawable.jpg_t86hpsafuv;
        item.id = "57ef81e49d17e00300d4df8f";
        addItem(item);
        item = new WatchesDSSchemaItem();
        item.text3 = "876";
        item.text1 = "Watch";
        item.text2 = "Men";
        item.picture = R.drawable.jpg_kie0dh0l39;
        item.id = "57ef81e79d17e00300d4df90";
        addItem(item);
        item = new WatchesDSSchemaItem();
        item.text3 = "345";
        item.text1 = "Watch";
        item.text2 = "Men";
        item.picture = R.drawable.jpg_jyoqsnsadu;
        item.id = "57ef82399d17e00300d4df93";
        addItem(item);
        item = new WatchesDSSchemaItem();
        item.text3 = "123";
        item.text1 = "Watch";
        item.text2 = "Men";
        item.picture = R.drawable.jpg_pjz1yie2nv;
        item.id = "57ef825f9d17e00300d4df94";
        addItem(item);
    }
    public static void addItem(WatchesDSSchemaItem item) {
        ITEMS.add(item);
    }
}


