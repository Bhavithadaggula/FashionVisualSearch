
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;

import ibmmobileappbuilder.ds.Count;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.Distinct;
import ibmmobileappbuilder.ds.Pagination;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import ibmmobileappbuilder.util.FilterUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * "WatchesDS" static data source (4383f0c1-e5dc-427b-9b74-082dbed76052)
 */
public class WatchesDS implements Datasource<WatchesDSSchemaItem>, Count,
            Pagination<WatchesDSSchemaItem>, Distinct {

    private static final int PAGE_SIZE = 20;

    private SearchOptions searchOptions;

    public static WatchesDS getInstance(SearchOptions searchOptions){
        return new WatchesDS(searchOptions);
    }

    private WatchesDS(SearchOptions searchOptions){
        this.searchOptions = searchOptions;
    }

    @Override
    public void getItems(Listener<List<WatchesDSSchemaItem>> listener) {
        listener.onSuccess(WatchesDSItems.ITEMS);
    }

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getItem(String id, Listener<WatchesDSSchemaItem> listener) {
        final int pos = Integer.parseInt(id);
        if(WatchesDSItems.ITEMS.size() <= pos){
        	listener.onSuccess(new WatchesDSSchemaItem());
        }
        else {
	        WatchesDSSchemaItem dc = WatchesDSItems.ITEMS.get(pos);
	        if( dc != null)
	            listener.onSuccess(dc);
	        else
	            listener.onFailure(new IllegalArgumentException("WatchesDSSchemaItem not found: " + pos));
	    }
    }

    @Override public int getCount(){
        return WatchesDSItems.ITEMS.size();
    }

    @Override
    public void getItems(int pagenum, Listener<List<WatchesDSSchemaItem>> listener) {
        int first = pagenum * PAGE_SIZE;
        int last = first + PAGE_SIZE;
        ArrayList<WatchesDSSchemaItem> result = new ArrayList<WatchesDSSchemaItem>();
        List<WatchesDSSchemaItem> filteredList = applySearchOptions(WatchesDSItems.ITEMS);
        if(first < filteredList.size())
            for (int i = first; (i < last) && (i < filteredList.size()); i++)
                result.add(filteredList.get(i));

        listener.onSuccess(result);
    }

    @Override
    public void onSearchTextChanged(String s){
        searchOptions.setSearchText(s);
    }

    @Override
    public void addFilter(Filter filter){
        searchOptions.addFilter(filter);
    }

    @Override
    public void clearFilters() {
        searchOptions.setFilters(null);
    }

    private List<WatchesDSSchemaItem> applySearchOptions(List<WatchesDSSchemaItem> result) {
        List<WatchesDSSchemaItem> filteredList = result;

        //Searching options
        String searchText = searchOptions.getSearchText();

        if(searchOptions.getFixedFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFixedFilters());

        if(searchOptions.getFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFilters());

        if (searchText != null && !"".equals(searchText))
            filteredList = applySearch(filteredList, searchText);

        //Sorting options
        Comparator comparator = searchOptions.getSortComparator();
        if (comparator != null) {
            if (searchOptions.isSortAscending()) {
                Collections.sort(filteredList, comparator);
            } else {
                Collections.sort(filteredList, Collections.reverseOrder(comparator));
            }
        }

        return filteredList;
    }

    private List<WatchesDSSchemaItem> applySearch(List<WatchesDSSchemaItem> items, String searchText) {
        List<WatchesDSSchemaItem> filteredList = new ArrayList<>();

        for (WatchesDSSchemaItem item : items) {
                        
            if (FilterUtils.searchInString(item.id, searchText) ||
            FilterUtils.searchInString(item.text1, searchText) ||
            FilterUtils.searchInString(item.text2, searchText) ||
            FilterUtils.searchInString(item.text3, searchText))
            {
                filteredList.add(item);
            }
        }

        return filteredList;

    }

    private List<WatchesDSSchemaItem> applyFilters(List<WatchesDSSchemaItem> items, List<Filter> filters) {
        List<WatchesDSSchemaItem> filteredList = new ArrayList<>();

        for (WatchesDSSchemaItem item : items) {
            if (
                FilterUtils.applyFilters("id", item.id, filters) &&
                FilterUtils.applyFilters("text1", item.text1, filters) &&
                FilterUtils.applyFilters("text2", item.text2, filters) &&
                FilterUtils.applyFilters("picture", item.picture, filters) &&
                FilterUtils.applyFilters("text3", item.text3, filters)
                ){

                filteredList.add(item);
            }
        }

        return filteredList;
    }

    // Distinct interface

    @Override
    public void getUniqueValuesFor(String columnName, Listener<List<String>> listener) {
        List<WatchesDSSchemaItem> filteredList = applySearchOptions(WatchesDSItems.ITEMS);
        listener.onSuccess(mapItems(filteredList, columnName));
    }

    private List<String> mapItems(List<WatchesDSSchemaItem> items, String columnName){
        // return only unique values
        ArrayList<String> res = new ArrayList();
        for (WatchesDSSchemaItem item: items){
            String mapped = mapItem(item, columnName);
            if(mapped != null && !res.contains(mapped))
                res.add(mapped);
        }

        return res;
    }

    private String mapItem(WatchesDSSchemaItem item, String columnName){
        // get fields
        switch (columnName){
                        
            case "id":
                return item.id;
            
            case "text1":
                return item.text1;
            
            case "text2":
                return item.text2;
            
            case "text3":
                return item.text3;
            default:
               return null;
        }
    }
}


