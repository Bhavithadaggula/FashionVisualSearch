

package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// AccessoriesDSSchemaItem static data
public class AccessoriesDSItems{

    public static List<AccessoriesDSSchemaItem> ITEMS = new ArrayList<AccessoriesDSSchemaItem>();
    static {
        // Add items.
        AccessoriesDSSchemaItem item;
        item = new AccessoriesDSSchemaItem();
        item.text1 = "Bangles";
        item.text2 = "Wear to hands";
        item.picture = R.drawable.jpg_caz1k2qrpd;
        item.text3 = "5.44";
        item.id = "57ef7dc29d17e00300d4df35";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "99.89";
        item.picture = R.drawable.jpg_15exhl0kpf;
        item.text2 = "party wear";
        item.text1 = "Bangles";
        item.id = "57ef7ebe57acb00300066581";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "89";
        item.picture = R.drawable.jpg_h3qbgt1uom;
        item.text2 = "Causal Wear";
        item.text1 = "Bangles";
        item.id = "57ef7ee457acb00300066584";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "66";
        item.picture = R.drawable.jpg_gjb0hqujg8;
        item.text2 = "Diamond ring";
        item.text1 = "Ring";
        item.id = "57ef7f2657acb00300066588";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "90";
        item.picture = R.drawable.jpg_htuju1qttc;
        item.text2 = "gold ring";
        item.text1 = "Ring";
        item.id = "57ef7f5557acb00300066589";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "72";
        item.picture = R.drawable.jpg_4v5cdhx80g;
        item.text2 = "Platinum ring";
        item.text1 = "Ring";
        item.id = "57ef7f809d17e00300d4df7d";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "45";
        item.picture = R.drawable.jpg_nq5vonbwzi;
        item.text2 = "silver ring";
        item.text1 = "Ring";
        item.id = "57ef7fa657acb0030006658f";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "77";
        item.text1 = "Ring";
        item.text2 = "Stones";
        item.picture = R.drawable.jpg_uoiwumaodq;
        item.id = "57ef7fc957acb00300066591";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "45";
        item.text1 = "Ring";
        item.text2 = "Daily Wear";
        item.picture = R.drawable.jpg_kdbk12aqw6;
        item.id = "57ef7fea57acb00300066592";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "43";
        item.picture = R.drawable.jpg_aiduqafp0o;
        item.text2 = "Casuals";
        item.text1 = "Bracelet";
        item.id = "57ef804257acb00300066594";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "56";
        item.picture = R.drawable.jpg_9mm8s49lvt;
        item.text2 = "casuals";
        item.text1 = "Bracelet";
        item.id = "57ef809157acb00300066597";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "99";
        item.text1 = "Bracelet";
        item.text2 = "casuals";
        item.picture = R.drawable.jpg_uwfohxlnvt;
        item.id = "57ef80b59d17e00300d4df87";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.text3 = "23";
        item.text1 = "Bracelet";
        item.text2 = "casuals";
        item.picture = R.drawable.jpg_okppfxjjfn;
        item.id = "57ef80ba57acb00300066599";
        addItem(item);
        item = new AccessoriesDSSchemaItem();
        item.picture = R.drawable.jpg_j7e6pecrph;
        item.text2 = "casuals";
        item.text1 = "Bracelet";
        item.id = "57ef80bf57acb0030006659a";
        addItem(item);
    }
    public static void addItem(AccessoriesDSSchemaItem item) {
        ITEMS.add(item);
    }
}


