

package com.ibm.mobileappbuilder.storecatalog20150911132549.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.storecatalog20150911132549.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * StoreCatalogScreen1Fragment menu fragment.
 */
public class StoreCatalogScreen1Fragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public StoreCatalogScreen1Fragment(){
        super();
    }

    // Factory method
    public static StoreCatalogScreen1Fragment newInstance(Bundle args) {
        StoreCatalogScreen1Fragment fragment = new StoreCatalogScreen1Fragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
                }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("JACKETS")
            .setIcon(R.drawable.jpg_download4484)
            .setAction(new StartActivityAction(JacketsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("TROUSERS")
            .setIcon(R.drawable.jpg_download6633)
            .setAction(new StartActivityAction(TrousersActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("SHIRTS")
            .setIcon(R.drawable.jpg_images5544)
            .setAction(new StartActivityAction(ShirtsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("TIES")
            .setIcon(R.drawable.jpg_download23354)
            .setAction(new StartActivityAction(TiesActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("women")
            .setIcon(R.drawable.jpg_images1521)
            .setAction(new StartActivityAction(WomenActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("watches")
            .setIcon(R.drawable.jpg_download17468)
            .setAction(new StartActivityAction(WatchesActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Accessories")
            .setIcon(R.drawable.jpg_download3890)
            .setAction(new StartActivityAction(AccessoriesActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Hats")
            .setIcon(R.drawable.jpg_download14913)
            .setAction(new StartActivityAction(HatsActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_list;
    }

    @Override
    public int getItemLayout() {
        return R.layout.storecatalogscreen1_item;
    }
}

